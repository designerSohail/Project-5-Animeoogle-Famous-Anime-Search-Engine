<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Animeoogle</title>
    <link href="https://fonts.googleapis.com/css?family=Metal+Mania|Open+Sans" rel="stylesheet">
    <style media="screen">
      <?php include 'css/style.css' ?>
    </style>
  </head>
  <body>
    <div class="alert">
      <h1>Not Available in Small devices.</h1>
      <h1>Working on it.</h1>
    </div>
    <div class="wrapper">
