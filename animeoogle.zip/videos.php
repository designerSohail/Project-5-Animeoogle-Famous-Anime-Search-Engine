<?php
  $location = 'videos';
  include 'inc/searchHeader.php';
  include 'inc/nav.php';
?>
<h3 style="text-align: center; margin: 9.35em 0em;">Comming Soon!</h3>
<?php
  include 'inc/footer.php';
?>
